export class Bien{
    id: number
    titre: string
    descrisption: string
    images: string
    catégories: string
}